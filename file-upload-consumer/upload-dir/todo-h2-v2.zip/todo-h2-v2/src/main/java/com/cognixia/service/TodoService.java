package com.cognixia.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognixia.common.exception.TodoNotFoundException;
import com.cognixia.model.Todo;
import com.cognixia.repository.TodoRepository;

@Service
public class TodoService {

	@Autowired
	TodoRepository todoRepository;

	public List<Todo> getTodos() {
		return todoRepository.findAll();
	}

	public Todo addTodo(Todo todo) {
		return todoRepository.save(todo);
	}

	public Todo getTodoById(int id) {
	
		return todoRepository.findById(id).orElseThrow(TodoNotFoundException::new);
	}

	public List<Todo> getTodosByUser(String user) {
	
		return todoRepository.findAllByTodoUser(user);
	}

	public List<Todo> getTodosByTargetDate(LocalDate date) {
		
		return todoRepository.getTodosByTargetDate(date);
	}
	
	public List<Todo> getTodosPending() {
		
		return todoRepository.findAllByDoneFalse();
	}
	public Todo updateTodo(Todo updateTodo) {
		getTodoById(updateTodo.getId());
		return addTodo(updateTodo);
	}

	public boolean deleteTodo(int id) {
		getTodoById(id);
		todoRepository.deleteById(id);
		return true;
	}

	public List<Todo> getTodosPendingByUser(String user) {
		
		return todoRepository.findAllByDoneFalseAndTodoUser(user);
	}

}
