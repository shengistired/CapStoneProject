package com.cognixia.common.exception;

public class TodoNotFoundException extends RuntimeException{

}
