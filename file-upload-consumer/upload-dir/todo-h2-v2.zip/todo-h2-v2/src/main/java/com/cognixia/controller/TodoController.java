package com.cognixia.controller;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cognixia.common.exception.TodoIDMismatchException;
import com.cognixia.model.Todo;
import com.cognixia.service.TodoService;

@RestController
@RequestMapping("/v2/todos")
public class TodoController {

	@Autowired
	TodoService todoService;
	
	@GetMapping
	public ResponseEntity<List<Todo>> getTodos()
	{
		return ResponseEntity.ok(todoService.getTodos());
	}
	
	@PostMapping
	public ResponseEntity<Todo> addTodo(@Valid @RequestBody Todo todo)
	{
		Todo createdTodo = todoService.addTodo(todo);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(createdTodo.getId()).toUri();
		return ResponseEntity.created(location).build();
	}

	@GetMapping("/{id}")
	public ResponseEntity<Todo> getTodoById(@PathVariable int id)
	{
		Todo todo = todoService.getTodoById(id);
		if(todo == null)
			return ResponseEntity.notFound().build(); 
		else
			return ResponseEntity.ok(todo);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Todo> updateTodo(@PathVariable int id, @Valid @RequestBody Todo todo)
	{
		if(id!=todo.getId())
			throw new TodoIDMismatchException("IDs must match");
		Todo updatedtodo = todoService.updateTodo(todo);
		if(updatedtodo == null)
			return ResponseEntity.notFound().build(); 
		else
			return ResponseEntity.ok(todo);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Todo> deleteTodo(@PathVariable int id)
	{
		if( todoService.deleteTodo(id))
			return ResponseEntity.noContent().build();
		else
			return ResponseEntity.notFound().build(); 
	}
	
	
	@GetMapping("user/{user}")
	public ResponseEntity<List<Todo>> getTodosByUser(@PathVariable String user)
	{
		return ResponseEntity.ok(todoService.getTodosByUser(user));
	}
	
	@GetMapping("date/{date}")
	public ResponseEntity<List<Todo>> getTodosByUser(@PathVariable LocalDate date)
	{
		return ResponseEntity.ok(todoService.getTodosByTargetDate(date));
	}
	
	@GetMapping("/pending")
	public ResponseEntity<List<Todo>> getTodosPending()
	{
		return ResponseEntity.ok(todoService.getTodosPending());
	}
	
	@GetMapping("/pending/{user}")
	public ResponseEntity<List<Todo>> getTodosPendingByUser(@PathVariable String user)
	{
		return ResponseEntity.ok(todoService.getTodosPendingByUser(user));
	}
}
