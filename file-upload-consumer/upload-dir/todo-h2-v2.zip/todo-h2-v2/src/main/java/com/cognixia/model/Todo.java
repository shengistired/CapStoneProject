package com.cognixia.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class Todo {

	@Id
	@GeneratedValue
	private int id;
	

	@NotBlank(message = "user cannot be blank")
	private String todoUser;
	
	@Size(min = 5, max=150, message = "Description must be between 5-150 characters")
	private String description;
	
	private boolean done;
	
	@FutureOrPresent(message = "Target date cannot be past!")
	private LocalDate targetDate;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTodoUser() {
		return todoUser;
	}
	public void setTodoUser(String todoUser) {
		this.todoUser = todoUser;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isDone() {
		return done;
	}
	public void setDone(boolean done) {
		this.done = done;
	}
	public LocalDate getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(LocalDate targetDate) {
		this.targetDate = targetDate;
	}
	
	public Todo() {
	}
	
	public Todo(int id, String todoUser, String description, boolean done, LocalDate targetDate) {
		super();
		this.id = id;
		this.todoUser = todoUser;
		this.description = description;
		this.done = done;
		this.targetDate = targetDate;
	}
}
