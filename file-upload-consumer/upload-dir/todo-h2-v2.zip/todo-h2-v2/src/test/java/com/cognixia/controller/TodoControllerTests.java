package com.cognixia.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.cognixia.model.Todo;
import com.cognixia.service.TodoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@AutoConfigureMockMvc
@SpringBootTest
public class TodoControllerTests {

	@Autowired
	MockMvc mvc;
	
    @MockBean
    private TodoService todoService;

	@Test
	public void addMockTodo()
	{
		
		Todo t = new Todo();
		t.setId(1);
		t.setTodoUser("MOCKTesting");
		t.setDescription("MOCK TODO");
		t.setDone(false);
		t.setTargetDate(LocalDate.of(2022,12,12));
		
		
		 Mockito.when(todoService.addTodo(Mockito.any())).thenReturn(t);
		 
		 
		ObjectMapper om = new ObjectMapper();
		om.registerModule(new JavaTimeModule());
		om.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		try {
			mvc.perform(post("/v2/todos").contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsString(t)))
			.andExpect(status().is(201))
			.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
}
