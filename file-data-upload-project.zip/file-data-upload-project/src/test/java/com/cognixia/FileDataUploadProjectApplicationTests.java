package com.cognixia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileDataUploadProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
