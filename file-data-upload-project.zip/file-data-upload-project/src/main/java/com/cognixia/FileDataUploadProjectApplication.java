package com.cognixia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileDataUploadProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileDataUploadProjectApplication.class, args);
	}

}
